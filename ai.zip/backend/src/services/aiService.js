import axios from 'axios';

class AIService {
  constructor() {
    this.deepseekApiKey = process.env.DEEPSEEK_API_KEY;
    this.chatgptApiKey = process.env.CHATGPT_API_KEY;
    this.deepseekApiUrl = 'https://api.deepseek.com/v1/chat/completions';
    this.chatgptApiUrl = 'https://api.openai.com/v1/chat/completions';
  }

  async sendToDeepSeek(message, conversationHistory = []) {
    try {
      const response = await axios.post(this.deepseekApiUrl, {
        model: 'deepseek-chat',
        messages: [
          ...conversationHistory,
          { role: 'user', content: message }
        ],
        max_tokens: 1000,
        temperature: 0.7,
        stream: false
      }, {
        headers: {
          'Authorization': `Bearer ${this.deepseekApiKey}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data.choices[0].message.content;
    } catch (error) {
      console.error('DeepSeek API调用失败:', error.response?.data || error.message);
      throw new Error('AI服务暂时不可用，请稍后重试');
    }
  }

  async sendToChatGPT(message, conversationHistory = []) {
    try {
      const response = await axios.post(this.chatgptApiUrl, {
        model: 'gpt-3.5-turbo',
        messages: [
          ...conversationHistory,
          { role: 'user', content: message }
        ],
        max_tokens: 1000,
        temperature: 0.7,
        stream: false
      }, {
        headers: {
          'Authorization': `Bearer ${this.chatgptApiKey}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data.choices[0].message.content;
    } catch (error) {
      console.error('ChatGPT API调用失败:', error.response?.data || error.message);
      throw new Error('AI服务暂时不可用，请稍后重试');
    }
  }

  async getAIResponse(message, conversationHistory = [], aiProvider = 'deepseek') {
    try {
      if (aiProvider === 'deepseek') {
        return await this.sendToDeepSeek(message, conversationHistory);
      } else if (aiProvider === 'chatgpt') {
        return await this.sendToChatGPT(message, conversationHistory);
      } else {
        // 默认使用DeepSeek
        return await this.sendToDeepSeek(message, conversationHistory);
      }
    } catch (error) {
      // 如果首选AI服务失败，尝试使用备用服务
      console.log(`尝试使用${aiProvider}失败，切换到备用服务`);
      
      if (aiProvider === 'deepseek') {
        try {
          return await this.sendToChatGPT(message, conversationHistory);
        } catch (fallbackError) {
          throw new Error('所有AI服务都暂时不可用，请稍后重试');
        }
      } else {
        try {
          return await this.sendToDeepSeek(message, conversationHistory);
        } catch (fallbackError) {
          throw new Error('所有AI服务都暂时不可用，请稍后重试');
        }
      }
    }
  }

  // 生成对话建议
  generateSuggestions() {
    const suggestions = [
      '帮我写一段JavaScript代码',
      '如何学习人工智能？',
      '解释一下量子计算的基本概念',
      '推荐一些提高编程效率的工具',
      '帮我分析这个业务需求',
      '如何优化网站性能？',
      '解释一下区块链技术',
      '帮我写一份产品介绍文档',
      '如何进行有效的时间管理？',
      '推荐一些学习资源'
    ];
    
    return suggestions.sort(() => Math.random() - 0.5).slice(0, 4);
  }

  // 验证消息内容
  validateMessage(message) {
    if (!message || message.trim().length === 0) {
      throw new Error('消息内容不能为空');
    }
    
    if (message.length > 2000) {
      throw new Error('消息内容过长，请控制在2000字符以内');
    }
    
    // 检查是否有敏感词（这里可以扩展为更复杂的敏感词过滤）
    const sensitiveWords = ['违法', '非法', '诈骗', '赌博'];
    if (sensitiveWords.some(word => message.toLowerCase().includes(word))) {
      throw new Error('消息内容包含违规内容');
    }
    
    return true;
  }

  // 分析消息类型
  analyzeMessageType(message) {
    const programmingKeywords = ['代码', '编程', 'function', 'class', '算法'];
    const learningKeywords = ['学习', '教程', '入门', '基础'];
    const businessKeywords = ['业务', '需求', '产品', '市场'];
    
    if (programmingKeywords.some(keyword => message.includes(keyword))) {
      return 'programming';
    } else if (learningKeywords.some(keyword => message.includes(keyword))) {
      return 'learning';
    } else if (businessKeywords.some(keyword => message.includes(keyword))) {
      return 'business';
    } else {
      return 'general';
    }
  }
}

export default new AIService();