import nodemailer from 'nodemailer';

// 创建邮件传输器
const createTransporter = () => {
  return nodemailer.createTransporter({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
};

// 发送验证码邮件
export const sendVerificationCode = async (email, code) => {
  try {
    const transporter = createTransporter();
    
    const mailOptions = {
      from: `"AI对话平台" <${process.env.SMTP_USER}>`,
      to: email,
      subject: 'AI对话平台 - 邮箱验证码',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #1E88E5, #64B5F6); padding: 20px; color: white; text-align: center;">
            <h1 style="margin: 0; font-size: 24px;">AI对话平台</h1>
          </div>
          <div style="padding: 30px; background: #f8f9fa;">
            <h2 style="color: #333; margin-bottom: 20px;">邮箱验证码</h2>
            <p style="color: #666; line-height: 1.6;">
              您正在注册AI对话平台账号，请使用以下验证码完成验证：
            </p>
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;">
              <span style="font-size: 32px; font-weight: bold; color: #1E88E5; letter-spacing: 8px;">
                ${code}
              </span>
            </div>
            <p style="color: #999; font-size: 12px; line-height: 1.4;">
              此验证码10分钟内有效，请勿将验证码泄露给他人。如非本人操作，请忽略此邮件。
            </p>
          </div>
          <div style="background: #f1f3f4; padding: 20px; text-align: center; color: #999; font-size: 12px;">
            <p>© 2024 AI对话平台. 保留所有权利.</p>
          </div>
        </div>
      `,
    };

    await transporter.sendMail(mailOptions);
    console.log(`验证码邮件已发送至: ${email}`);
    return true;
  } catch (error) {
    console.error('发送邮件失败:', error);
    throw new Error('邮件发送失败');
  }
};