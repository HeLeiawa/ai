import express from 'express';
import authRoutes from './auth.js';
import userRoutes from './user.js';
import chatRoutes from './chat.js';
import adminRoutes from './admin.js';

const router = express.Router();

// API路由前缀
router.use('/auth', authRoutes);
router.use('/user', userRoutes);
router.use('/chat', chatRoutes);
router.use('/admin', adminRoutes);

// 健康检查
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
  });
});

// 404处理
router.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: '接口不存在',
    path: req.originalUrl,
  });
});

// 错误处理中间件
router.use((err, req, res, next) => {
  console.error('API错误:', err);
  
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      message: '参数验证失败',
      errors: err.errors,
    });
  }
  
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      success: false,
      message: '身份验证失败',
    });
  }
  
  res.status(500).json({
    success: false,
    message: '服务器内部错误',
  });
});

export default router;