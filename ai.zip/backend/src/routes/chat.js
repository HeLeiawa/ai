import express from 'express';
import { body, validationResult } from 'express-validator';
import { authenticateToken } from '../middleware/auth.js';
import ChatSession from '../models/ChatSession.js';
import ChatMessage from '../models/ChatMessage.js';

const router = express.Router();

// 获取用户的所有会话
router.get('/sessions', authenticateToken, async (req, res) => {
  try {
    const sessions = await ChatSession.findAll({
      where: { user_id: req.user.id },
      order: [['updated_at', 'DESC']]
    });

    res.json({ sessions });
  } catch (error) {
    console.error('获取会话列表错误:', error);
    res.status(500).json({ error: '获取会话列表失败' });
  }
});

// 创建新会话
router.post('/sessions', [
  authenticateToken,
  body('title').isLength({ min: 1, max: 200 }),
  body('model').isIn(['deepseek', 'chatgpt'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { title, model } = req.body;

    const session = await ChatSession.create({
      title,
      model,
      user_id: req.user.id
    });

    res.status(201).json({
      message: '会话创建成功',
      session
    });
  } catch (error) {
    console.error('创建会话错误:', error);
    res.status(500).json({ error: '创建会话失败' });
  }
});

// 获取会话的详细信息
router.get('/sessions/:sessionId', authenticateToken, async (req, res) => {
  try {
    const { sessionId } = req.params;

    const session = await ChatSession.findOne({
      where: {
        id: sessionId,
        user_id: req.user.id
      }
    });

    if (!session) {
      return res.status(404).json({ error: '会话不存在' });
    }

    res.json({ session });
  } catch (error) {
    console.error('获取会话详情错误:', error);
    res.status(500).json({ error: '获取会话详情失败' });
  }
});

// 获取会话的消息列表
router.get('/sessions/:sessionId/messages', authenticateToken, async (req, res) => {
  try {
    const { sessionId } = req.params;

    // 验证会话所有权
    const session = await ChatSession.findOne({
      where: {
        id: sessionId,
        user_id: req.user.id
      }
    });

    if (!session) {
      return res.status(404).json({ error: '会话不存在' });
    }

    const messages = await ChatMessage.findAll({
      where: { session_id: sessionId },
      order: [['created_at', 'ASC']]
    });

    res.json({ messages });
  } catch (error) {
    console.error('获取消息列表错误:', error);
    res.status(500).json({ error: '获取消息列表失败' });
  }
});

// 发送消息到AI
router.post('/sessions/:sessionId/messages', [
  authenticateToken,
  body('content').isLength({ min: 1 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { sessionId } = req.params;
    const { content } = req.body;

    // 验证会话所有权
    const session = await ChatSession.findOne({
      where: {
        id: sessionId,
        user_id: req.user.id
      }
    });

    if (!session) {
      return res.status(404).json({ error: '会话不存在' });
    }

    // 保存用户消息
    const userMessage = await ChatMessage.create({
      session_id: sessionId,
      role: 'user',
      content
    });

    // 调用AI API（这里需要集成DeepSeek和ChatGPT API）
    let aiResponse = "这是AI的回复示例。实际应该调用对应的API。";
    
    // 模拟AI回复
    if (session.model === 'deepseek') {
      aiResponse = `DeepSeek回复：${content} - 这是模拟的DeepSeek API回复`;
    } else if (session.model === 'chatgpt') {
      aiResponse = `ChatGPT回复：${content} - 这是模拟的ChatGPT API回复`;
    }

    // 保存AI回复
    const aiMessage = await ChatMessage.create({
      session_id: sessionId,
      role: 'assistant',
      content: aiResponse
    });

    // 更新会话时间
    await session.update({ updated_at: new Date() });

    res.json({
      message: '消息发送成功',
      userMessage,
      aiMessage
    });
  } catch (error) {
    console.error('发送消息错误:', error);
    res.status(500).json({ error: '发送消息失败' });
  }
});

// 删除会话
router.delete('/sessions/:sessionId', authenticateToken, async (req, res) => {
  try {
    const { sessionId } = req.params;

    const session = await ChatSession.findOne({
      where: {
        id: sessionId,
        user_id: req.user.id
      }
    });

    if (!session) {
      return res.status(404).json({ error: '会话不存在' });
    }

    // 删除会话相关的所有消息
    await ChatMessage.destroy({
      where: { session_id: sessionId }
    });

    // 删除会话
    await session.destroy();

    res.json({ message: '会话删除成功' });
  } catch (error) {
    console.error('删除会话错误:', error);
    res.status(500).json({ error: '删除会话失败' });
  }
});

export default router;