import express from 'express';
import { body, validationResult } from 'express-validator';
import { authenticateToken } from '../middleware/auth.js';
import User from '../models/User.js';

const router = express.Router();

// 获取用户个人信息
router.get('/profile', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password'] }
    });
    
    res.json({
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        gender: user.gender,
        bio: user.bio,
        role: user.role,
        is_verified: user.is_verified,
        created_at: user.created_at
      }
    });
  } catch (error) {
    console.error('获取用户信息错误:', error);
    res.status(500).json({ error: '获取用户信息失败' });
  }
});

// 更新用户个人信息
router.put('/profile', [
  authenticateToken,
  body('username').optional().isLength({ min: 1, max: 50 }),
  body('gender').optional().isIn(['male', 'female', 'other']),
  body('bio').optional().isLength({ max: 500 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { username, gender, bio } = req.body;
    const user = await User.findByPk(req.user.id);

    await user.update({
      username: username || user.username,
      gender: gender || user.gender,
      bio: bio || user.bio
    });

    res.json({
      message: '个人信息更新成功',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        gender: user.gender,
        bio: user.bio,
        role: user.role
      }
    });
  } catch (error) {
    console.error('更新用户信息错误:', error);
    res.status(500).json({ error: '更新用户信息失败' });
  }
});

// 上传头像
router.post('/avatar', authenticateToken, async (req, res) => {
  try {
    // 这里简化处理，实际应该使用multer等中间件处理文件上传
    // 这里假设前端已经将图片上传到CDN并返回了URL
    const { avatarUrl } = req.body;

    if (!avatarUrl) {
      return res.status(400).json({ error: '头像URL不能为空' });
    }

    const user = await User.findByPk(req.user.id);
    await user.update({ avatar: avatarUrl });

    res.json({
      message: '头像上传成功',
      avatar: avatarUrl
    });
  } catch (error) {
    console.error('上传头像错误:', error);
    res.status(500).json({ error: '上传头像失败' });
  }
});

export default router;