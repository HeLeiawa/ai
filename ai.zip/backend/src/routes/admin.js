import express from 'express';
import { body, validationResult } from 'express-validator';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';
import User from '../models/User.js';

const router = express.Router();

// 获取所有用户列表
router.get('/users', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 20, search = '' } = req.query;
    const offset = (page - 1) * limit;

    const whereClause = {};
    if (search) {
      whereClause.email = {
        [Symbol.for('like')]: `%${search}%`
      };
    }

    const users = await User.findAll({
      where: whereClause,
      attributes: { exclude: ['password'] },
      order: [['created_at', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    const total = await User.count({ where: whereClause });

    res.json({
      users,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('获取用户列表错误:', error);
    res.status(500).json({ error: '获取用户列表失败' });
  }
});

// 获取用户详细信息
router.get('/users/:userId', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { userId } = req.params;

    const user = await User.findByPk(userId, {
      attributes: { exclude: ['password'] }
    });

    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }

    res.json({ user });
  } catch (error) {
    console.error('获取用户详情错误:', error);
    res.status(500).json({ error: '获取用户详情失败' });
  }
});

// 封禁用户
router.post('/users/:userId/ban', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { userId } = req.params;

    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }

    if (user.role === 'admin') {
      return res.status(400).json({ error: '不能封禁管理员' });
    }

    await user.update({ is_banned: true });

    res.json({ message: '用户封禁成功' });
  } catch (error) {
    console.error('封禁用户错误:', error);
    res.status(500).json({ error: '封禁用户失败' });
  }
});

// 解封用户
router.post('/users/:userId/unban', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { userId } = req.params;

    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }

    await user.update({ is_banned: false });

    res.json({ message: '用户解封成功' });
  } catch (error) {
    console.error('解封用户错误:', error);
    res.status(500).json({ error: '解封用户失败' });
  }
});

// 创建用户（管理员创建）
router.post('/users', [
  authenticateToken,
  requireAdmin,
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
  body('username').optional().isLength({ min: 1, max: 50 }),
  body('role').optional().isIn(['user', 'admin'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password, username, role = 'user' } = req.body;

    // 检查邮箱是否已存在
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ error: '该邮箱已被注册' });
    }

    const user = await User.create({
      email,
      password,
      username: username || `用户${Date.now().toString().slice(-6)}`,
      role,
      is_verified: true
    });

    res.status(201).json({
      message: '用户创建成功',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role,
        is_verified: user.is_verified
      }
    });
  } catch (error) {
    console.error('创建用户错误:', error);
    if (error.name === 'SequelizeUniqueConstraintError') {
      res.status(400).json({ error: '该邮箱已被注册' });
    } else {
      res.status(500).json({ error: '创建用户失败' });
    }
  }
});

// 获取平台统计信息
router.get('/stats', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const totalUsers = await User.count();
    const activeUsers = await User.count({ where: { is_active: true } });
    const bannedUsers = await User.count({ where: { is_banned: true } });
    const adminUsers = await User.count({ where: { role: 'admin' } });

    // 这里可以添加更多统计信息，如会话数量、消息数量等

    res.json({
      stats: {
        totalUsers,
        activeUsers,
        bannedUsers,
        adminUsers
      }
    });
  } catch (error) {
    console.error('获取统计信息错误:', error);
    res.status(500).json({ error: '获取统计信息失败' });
  }
});

export default router;