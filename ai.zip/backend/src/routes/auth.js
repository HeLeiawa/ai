import express from 'express';
import jwt from 'jsonwebtoken';
import { body, validationResult } from 'express-validator';
import User from '../models/User.js';
import VerificationCode from '../models/VerificationCode.js';
import { sendVerificationCode } from '../services/emailService.js';
import { generateCode } from '../utils/helpers.js';

const router = express.Router();

// 生成JWT令牌
const generateToken = (user) => {
  return jwt.sign(
    { 
      id: user.id, 
      email: user.email, 
      role: user.role 
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
};

// 发送验证码
router.post('/send-code', [
  body('email').isEmail().normalizeEmail()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email } = req.body;
    
    // 检查邮箱是否已被注册
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ error: '该邮箱已被注册' });
    }

    // 生成验证码
    const code = generateCode(6);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10分钟过期

    // 保存验证码到数据库
    await VerificationCode.create({
      email,
      code,
      type: 'register',
      expires_at: expiresAt
    });

    // 发送邮件
    await sendVerificationCode(email, code);

    res.json({ 
      message: '验证码已发送',
      expiresAt: expiresAt.toISOString()
    });
  } catch (error) {
    console.error('发送验证码错误:', error);
    res.status(500).json({ error: '发送验证码失败' });
  }
});

// 用户注册
router.post('/register', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
  body('code').isLength({ min: 6, max: 6 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password, code } = req.body;

    // 验证验证码
    const verificationCode = await VerificationCode.findOne({
      where: { 
        email, 
        code, 
        type: 'register',
        is_used: false,
        expires_at: { [Symbol.for('gt')]: new Date() }
      }
    });

    if (!verificationCode) {
      return res.status(400).json({ error: '验证码无效或已过期' });
    }

    // 创建用户
    const user = await User.create({
      email,
      password,
      username: `用户${Date.now().toString().slice(-6)}`,
      is_verified: true
    });

    // 标记验证码为已使用
    await verificationCode.update({ is_used: true });

    // 生成令牌
    const token = generateToken(user);

    res.status(201).json({
      message: '注册成功',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        role: user.role
      },
      token
    });
  } catch (error) {
    console.error('注册错误:', error);
    if (error.name === 'SequelizeUniqueConstraintError') {
      res.status(400).json({ error: '该邮箱已被注册' });
    } else {
      res.status(500).json({ error: '注册失败' });
    }
  }
});

// 用户登录
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password } = req.body;
    const clientIP = req.ip || req.connection.remoteAddress;

    // 查找用户
    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(401).json({ error: '邮箱或密码错误' });
    }

    // 检查账号是否被封禁
    if (user.is_banned) {
      return res.status(403).json({ error: '账号已被封禁' });
    }

    // 检查登录限制
    if (user.lock_until && user.lock_until > new Date()) {
      const remainingTime = Math.ceil((user.lock_until - new Date()) / 1000 / 60);
      return res.status(429).json({ 
        error: `账号已被锁定，请在${remainingTime}分钟后重试` 
      });
    }

    // 验证密码
    const isValidPassword = await user.validatePassword(password);
    if (!isValidPassword) {
      // 增加登录尝试次数
      const attempts = user.login_attempts + 1;
      let lockUntil = null;
      
      if (attempts >= 5) {
        lockUntil = new Date(Date.now() + 30 * 60 * 1000); // 锁定30分钟
      }

      await user.update({
        login_attempts: attempts,
        lock_until: lockUntil
      });

      return res.status(401).json({ error: '邮箱或密码错误' });
    }

    // 登录成功，重置计数器
    await user.update({
      login_attempts: 0,
      lock_until: null,
      last_login_ip: clientIP,
      last_login_at: new Date()
    });

    // 生成令牌
    const token = generateToken(user);

    res.json({
      message: '登录成功',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        role: user.role
      },
      token
    });
  } catch (error) {
    console.error('登录错误:', error);
    res.status(500).json({ error: '登录失败' });
  }
});

// 刷新令牌
router.post('/refresh', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: '未提供令牌' });
    }

    const token = authHeader.slice(7);
    
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findByPk(decoded.id);
      
      if (!user || user.is_banned) {
        return res.status(401).json({ error: '令牌无效' });
      }

      const newToken = generateToken(user);
      res.json({ token: newToken });
    } catch (jwtError) {
      res.status(401).json({ error: '令牌无效或已过期' });
    }
  } catch (error) {
    console.error('刷新令牌错误:', error);
    res.status(500).json({ error: '刷新令牌失败' });
  }
});

export default router;