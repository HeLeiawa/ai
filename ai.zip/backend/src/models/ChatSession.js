import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const ChatSession = sequelize.define('ChatSession', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  title: {
    type: DataTypes.STRING(200),
    allowNull: false,
    defaultValue: '新对话',
  },
  model: {
    type: DataTypes.ENUM('deepseek', 'chatgpt'),
    allowNull: false,
    defaultValue: 'deepseek',
  },
  user_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id',
    },
  },
}, {
  tableName: 'chat_sessions',
});

export default ChatSession;