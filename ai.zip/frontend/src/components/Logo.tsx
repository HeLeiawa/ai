import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'light' | 'dark';
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ size = 'md', variant = 'dark', className = '' }) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12',
  };

  const textClasses = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl',
  };

  const colorClasses = {
    light: 'text-white',
    dark: 'text-blue-600',
  };

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      {/* Logo图标 */}
      <div className={`${sizeClasses[size]} bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg flex items-center justify-center`}>
        <svg 
          className={`${sizeClasses[size].replace('w-', 'w-').replace('h-', 'h-')} ${variant === 'light' ? 'text-white' : 'text-white'}`} 
          fill="currentColor" 
          viewBox="0 0 24 24"
        >
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      </div>
      
      {/* Logo文字 */}
      <span className={`font-bold ${textClasses[size]} ${colorClasses[variant]}`}>
        AI智能平台
      </span>
    </div>
  );
};

export default Logo;