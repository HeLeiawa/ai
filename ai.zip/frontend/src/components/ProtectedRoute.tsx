import React, { useEffect } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import { RootState } from '../store/store'
import { verifyToken } from '../store/slices/authSlice'

interface ProtectedRouteProps {
  children: React.ReactElement
  requireAdmin?: boolean
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  requireAdmin = false 
}) => {
  const { isAuthenticated, user, isLoading } = useSelector((state: RootState) => state.auth)
  const dispatch = useDispatch()
  const location = useLocation()

  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      const token = localStorage.getItem('token')
      if (token) {
        dispatch(verifyToken() as any)
      }
    }
  }, [isAuthenticated, isLoading, dispatch])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }

  if (requireAdmin && user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">权限不足</h1>
          <p className="text-gray-600 mb-4">您需要管理员权限才能访问此页面。</p>
          <Navigate to="/" replace />
        </div>
      </div>
    )
  }

  return children
}

export default ProtectedRoute