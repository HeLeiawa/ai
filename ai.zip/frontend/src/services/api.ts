import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001/api';

// 创建axios实例
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 请求拦截器
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 响应拦截器
api.interceptors.response.use(
  (response) => {
    return response.data;
  },
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error.response?.data || error);
  }
);

// 认证相关API
export const authAPI = {
  // 发送验证码
  sendVerificationCode: async (email: string) => {
    return await api.post('/auth/send-verification-code', { email });
  },

  // 注册
  register: async (data: {
    email: string;
    password: string;
    code: string;
    name?: string;
  }) => {
    return await api.post('/auth/register', data);
  },

  // 登录
  login: async (email: string, password: string) => {
    return await api.post('/auth/login', { email, password });
  },

  // 获取当前用户信息
  getCurrentUser: async (token: string) => {
    return await api.get('/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 刷新token
  refreshToken: async (refreshToken: string) => {
    return await api.post('/auth/refresh', { refreshToken });
  },

  // 登出
  logout: async (token: string) => {
    return await api.post('/auth/logout', {}, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 重置密码
  resetPassword: async (email: string, code: string, newPassword: string) => {
    return await api.post('/auth/reset-password', {
      email,
      code,
      newPassword,
    });
  },
};

// 用户相关API
export const userAPI = {
  // 更新用户信息
  updateProfile: async (data: {
    name?: string;
    gender?: string;
    bio?: string;
    avatar?: string;
  }, token: string) => {
    return await api.put('/user/profile', data, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 修改密码
  changePassword: async (oldPassword: string, newPassword: string, token: string) => {
    return await api.put('/user/password', {
      oldPassword,
      newPassword,
    }, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 获取用户统计信息
  getUserStats: async (token: string) => {
    return await api.get('/user/stats', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
};

// 聊天相关API
export const chatAPI = {
  // 发送消息
  sendMessage: async (message: string, token: string, sessionId?: string) => {
    return await api.post('/chat/message', {
      message,
      sessionId,
    }, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 获取对话历史
  getChatHistory: async (token: string, page = 1, limit = 20) => {
    return await api.get('/chat/history', {
      params: { page, limit },
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 获取对话详情
  getChatSession: async (sessionId: string, token: string) => {
    return await api.get(`/chat/session/${sessionId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 删除对话
  deleteChatSession: async (sessionId: string, token: string) => {
    return await api.delete(`/chat/session/${sessionId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 获取对话建议
  getSuggestions: async (token: string) => {
    return await api.get('/chat/suggestions', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
};

// 管理员API
export const adminAPI = {
  // 获取所有用户
  getUsers: async (token: string, page = 1, limit = 20) => {
    return await api.get('/admin/users', {
      params: { page, limit },
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 封禁用户
  banUser: async (userId: string, token: string) => {
    return await api.put(`/admin/users/${userId}/ban`, {}, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 解封用户
  unbanUser: async (userId: string, token: string) => {
    return await api.put(`/admin/users/${userId}/unban`, {}, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 创建用户
  createUser: async (data: {
    email: string;
    password: string;
    name?: string;
  }, token: string) => {
    return await api.post('/admin/users', data, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 获取系统统计
  getSystemStats: async (token: string) => {
    return await api.get('/admin/stats', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  // 获取操作日志
  getOperationLogs: async (token: string, page = 1, limit = 50) => {
    return await api.get('/admin/logs', {
      params: { page, limit },
      headers: { Authorization: `Bearer ${token}` },
    });
  },
};

// 导出所有API
export const apiMethods = {
  ...authAPI,
  ...userAPI,
  ...chatAPI,
  ...adminAPI,
};

// 兼容旧版导出
export const sendMessage = chatAPI.sendMessage;
export const updateUserProfile = userAPI.updateProfile;
export const getUsers = adminAPI.getUsers;
export const banUser = adminAPI.banUser;
export const unbanUser = adminAPI.unbanUser;
export const createUser = adminAPI.createUser;

export default api;