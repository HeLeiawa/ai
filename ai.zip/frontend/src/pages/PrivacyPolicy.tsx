import React from 'react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-6 py-8">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        {/* 头部 */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 px-8 py-12 text-center">
          <h1 className="text-4xl font-bold text-white mb-4">隐私政策</h1>
          <p className="text-blue-200 text-lg">最后更新日期：2024年1月1日</p>
        </div>

        {/* 内容 */}
        <div className="px-8 py-12">
          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">引言</h2>
              <p className="text-gray-700 mb-4">
                欢迎使用我们的AI智能平台。我们深知个人信息对您的重要性，并致力于保护您的隐私。
                本隐私政策旨在说明我们如何收集、使用、存储和保护您的个人信息。
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">信息收集</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">注册信息</h3>
                  <ul className="list-disc list-inside text-gray-700 space-y-1">
                    <li>邮箱地址 - 用于账号注册和验证</li>
                    <li>密码 - 经过加密处理后存储</li>
                    <li>验证码 - 用于邮箱验证</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">个人信息</h3>
                  <ul className="list-disc list-inside text-gray-700 space-y-1">
                    <li>姓名（可选）</li>
                    <li>性别（可选）</li>
                    <li>个人介绍（可选）</li>
                    <li>头像图片链接（可选）</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">使用数据</h3>
                  <ul className="list-disc list-inside text-gray-700 space-y-1">
                    <li>IP地址 - 用于安全防护和数据分析</li>
                    <li>设备信息 - 浏览器类型、操作系统等</li>
                    <li>使用记录 - 对话历史、操作日志等</li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">信息使用</h2>
              <p className="text-gray-700 mb-4">
                我们仅会出于以下目的使用您的个人信息：
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>提供和维护AI智能服务</li>
                <li>处理用户注册和身份验证</li>
                <li>改善用户体验和优化服务</li>
                <li>发送重要的服务通知</li>
                <li>保障平台安全和防止欺诈</li>
                <li>遵守法律法规要求</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">信息共享</h2>
              <p className="text-gray-700 mb-4">
                我们承诺不会将您的个人信息出售给任何第三方。仅在以下情况下，我们可能会共享信息：
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>获得您明确同意的情况下</li>
                <li>为提供您要求的服务而必须共享</li>
                <li>遵守法律法规或政府机关的要求</li>
                <li>保护我们的权利、财产或安全</li>
                <li>在涉及合并、收购或破产时</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">数据安全</h2>
              <p className="text-gray-700 mb-4">
                我们采用行业标准的安全措施来保护您的个人信息：
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>数据传输使用SSL加密技术</li>
                <li>密码经过bcrypt算法加密存储</li>
                <li>定期进行安全漏洞扫描和修复</li>
                <li>严格的访问控制和权限管理</li>
                <li>定期备份重要数据</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">您的权利</h2>
              <p className="text-gray-700 mb-4">
                您对自己的个人信息享有以下权利：
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li><strong>访问权</strong> - 查看我们持有的您的个人信息</li>
                <li><strong>更正权</strong> - 更正不准确或不完整的个人信息</li>
                <li><strong>删除权</strong> - 在特定情况下要求删除个人信息</li>
                <li><strong>限制处理权</strong> - 限制我们对您信息的使用</li>
                <li><strong>数据携带权</strong> - 获取您的个人信息副本</li>
                <li><strong>反对权</strong> - 反对特定类型的个人信息处理</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Cookie政策</h2>
              <p className="text-gray-700 mb-4">
                我们使用Cookie和类似技术来改善用户体验：
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li><strong>必要Cookie</strong> - 用于网站基本功能</li>
                <li><strong>偏好Cookie</strong> - 记住您的设置和偏好</li>
                <li><strong>分析Cookie</strong> - 帮助我们了解用户行为</li>
                <li><strong>营销Cookie</strong> - 提供相关广告内容</li>
              </ul>
              <p className="text-gray-700 mt-4">
                您可以通过浏览器设置管理Cookie偏好。
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">儿童隐私</h2>
              <p className="text-gray-700">
                我们的服务不面向13周岁以下的儿童。如果我们发现无意中收集了儿童的个人信息，
                我们将立即采取措施删除这些信息。
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">政策变更</h2>
              <p className="text-gray-700">
                我们可能会不时更新本隐私政策。如有重大变更，我们将在网站上发布通知，
                并通过邮件通知您。建议您定期查看本政策以了解最新内容。
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">联系我们</h2>
              <p className="text-gray-700">
                如果您对本隐私政策有任何疑问、意见或建议，请通过以下方式联系我们：
              </p>
              <div className="bg-gray-50 rounded-lg p-4 mt-4">
                <p className="text-gray-700">
                  <strong>邮箱：</strong>privacy@aiplatform.com
                </p>
                <p className="text-gray-700 mt-2">
                  <strong>工作时间：</strong>周一至周五 9:00-18:00
                </p>
              </div>
            </section>

            <div className="bg-blue-50 rounded-lg p-6 mt-8">
              <h3 className="text-lg font-semibold text-blue-900 mb-2">备案信息</h3>
              <p className="text-blue-700">
                ICP备案号：京ICP备12345678号-1<br />
                公安联网备案号：京公网安备 11000000000001号
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;