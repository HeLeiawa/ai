import React from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { RootState } from '../store/store'
import { MessageSquare, Zap, Shield, Users, Star, CheckCircle } from 'lucide-react'

const Home: React.FC = () => {
  const { isAuthenticated } = useSelector((state: RootState) => state.auth)

  const features = [
    {
      icon: <MessageSquare className="w-8 h-8 text-blue-600" />,
      title: '智能对话',
      description: '集成DeepSeek和ChatGPT，提供流畅自然的对话体验'
    },
    {
      icon: <Zap className="w-8 h-8 text-blue-600" />,
      title: '高速响应',
      description: '优化的API调用，确保毫秒级响应速度'
    },
    {
      icon: <Shield className="w-8 h-8 text-blue-600" />,
      title: '安全可靠',
      description: '端到端加密，保护用户隐私和数据安全'
    },
    {
      icon: <Users className="w-8 h-8 text-blue-600" />,
      title: '多用户支持',
      description: '完善的用户系统，支持个人化设置'
    }
  ]

  const comparisons = [
    {
      feature: 'AI模型支持',
      ourPlatform: 'DeepSeek + ChatGPT',
      competitorA: '仅DeepSeek',
      competitorB: '仅ChatGPT'
    },
    {
      feature: '响应速度',
      ourPlatform: '毫秒级',
      competitorA: '中等',
      competitorB: '较慢'
    },
    {
      feature: '使用成本',
      ourPlatform: '免费试用',
      competitorA: '按量收费',
      competitorB: '订阅制'
    },
    {
      feature: '技术支持',
      ourPlatform: '7×24小时',
      competitorA: '工作时间',
      competitorB: '邮件支持'
    }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-blue-100 py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              专业的
              <span className="gradient-text"> AI对话</span>
              <br />
              平台
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              集成DeepSeek和ChatGPT等先进AI模型，为用户提供智能、高效、安全的对话体验。
              无论是日常咨询、学习辅导还是创意协作，我们都能满足您的需求。
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {isAuthenticated ? (
                <Link to="/chat" className="btn-primary text-lg px-8 py-4">
                  开始对话
                </Link>
              ) : (
                <>
                  <Link to="/register" className="btn-primary text-lg px-8 py-4">
                    免费注册
                  </Link>
                  <Link to="/login" className="btn-outline text-lg px-8 py-4">
                    立即登录
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              为什么选择我们？
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              我们致力于为用户提供最佳的AI对话体验，结合技术创新和用户需求设计
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="card-hover p-6 text-center">
                <div className="flex justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              平台对比
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              与其他AI平台相比，我们提供更全面的服务和更好的用户体验
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-medium overflow-hidden">
            <div className="grid grid-cols-4 gap-0 border-b border-gray-200">
              <div className="p-6 font-semibold text-gray-900">功能特性</div>
              <div className="p-6 font-semibold text-blue-600 text-center">AI对话平台</div>
              <div className="p-6 font-semibold text-gray-700 text-center">平台A</div>
              <div className="p-6 font-semibold text-gray-700 text-center">平台B</div>
            </div>
            
            {comparisons.map((item, index) => (
              <div key={index} className="grid grid-cols-4 gap-0 border-b border-gray-100 last:border-b-0">
                <div className="p-6 text-gray-700">{item.feature}</div>
                <div className="p-6 text-blue-600 font-medium text-center">
                  <div className="flex items-center justify-center space-x-1">
                    <CheckCircle className="w-4 h-4" />
                    <span>{item.ourPlatform}</span>
                  </div>
                </div>
                <div className="p-6 text-gray-600 text-center">{item.competitorA}</div>
                <div className="p-6 text-gray-600 text-center">{item.competitorB}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-500">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            准备好体验智能对话了吗？
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            立即注册，开始您与AI的精彩对话之旅
          </p>
          {!isAuthenticated && (
            <Link to="/register" className="btn-secondary bg-white text-blue-600 hover:bg-blue-50 text-lg px-8 py-4">
              免费注册
            </Link>
          )}
        </div>
      </section>
    </div>
  )
}

export default Home